package com.example.spotifyapp2340;
import java.util.List;

public class UserTopArtist {

        public static final String CLIENT_ID = "bba1543448324cecabcc2a9328c94179";
        private String userId;
        private String name;
        private String imageUrl;
        private List<UserTopArtist> artists;

        public UserTopArtist() {
            // Default constructor required for calls to DataSnapshot.getValue(UserTopArtists.class)
        }
        public UserTopArtist(String name, String imageUrl) {
        this.name = name;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UserTopArtist(String userId, List<UserTopArtist> artists) {
            this.userId = userId;
            this.artists = artists;
        }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public List<UserTopArtist> getUserTopArtists() {
            return artists;
        }

        public void setArtists(List<UserTopArtist> artists) {
            this.artists = artists;
        }

        // Ensure you have a matching getter for every setter if you're using Firebase Realtime Database.
    }

