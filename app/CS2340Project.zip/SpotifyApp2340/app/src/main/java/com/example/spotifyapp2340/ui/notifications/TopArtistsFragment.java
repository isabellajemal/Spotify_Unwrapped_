package com.example.spotifyapp2340.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.spotifyapp2340.ArtistsAdapter;
import com.example.spotifyapp2340.databinding.FragmentNotificationsBinding;

public class TopArtistsFragment extends Fragment {

    private FragmentNotificationsBinding binding;
    private ArtistsAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        // Initialize binding
        binding = FragmentNotificationsBinding.inflate(inflater, container, false);

        // Setup RecyclerView and Adapter
        adapter = new ArtistsAdapter(); // Assuming you have a no-argument constructor
        binding.recyclerViewArtists.setAdapter(adapter);
        binding.recyclerViewArtists.setLayoutManager(new LinearLayoutManager(getContext()));

        // Load top artists for a given user ID
        loadUserTopArtists("someUserId"); // You need to replace this with actual logic to get the userId

        // Return the root view from the binding
        return binding.getRoot();
    }

    public void loadUserTopArtists(String userId) {
        // Assuming your ArtistsAdapter already implements the logic to load and display artists
        adapter.loadUserTopArtists(userId);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Clean up binding when the view is destroyed
    }
}